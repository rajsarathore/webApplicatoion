package com.web.model;

public class UserRegistration {
	private long userID;
	private String userName;
	private String userRole;
	private String userEmail;
	private String userDOB;
	private long userPhone;
	private String userPassword;
	private String userRetypePassword;
	private String userSecurityQuestion;
	private String userSecurityAnswer;
	public long getUserID() {
		return userID;
	}
	public void setUserID(long userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserDOB() {
		return userDOB;
	}
	public void setUserDOB(String userDOB) {
		this.userDOB = userDOB;
	}
	public long getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserRetypePassword() {
		return userRetypePassword;
	}
	public void setUserRetypePassword(String userRetypePassword) {
		this.userRetypePassword = userRetypePassword;
	}
	public String getUserSecurityQuestion() {
		return userSecurityQuestion;
	}
	public void setUserSecurityQuestion(String userSecurityQuestion) {
		this.userSecurityQuestion = userSecurityQuestion;
	}
	public String getUserSecurityAnswer() {
		return userSecurityAnswer;
	}
	public void setUserSecurityAnswer(String userSecurityAnswer) {
		this.userSecurityAnswer = userSecurityAnswer;
	}
	
	

}
