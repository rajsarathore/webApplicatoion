package com.web.validation;

import java.util.List;

import com.web.model.UserRegistration;

public class RegistrationValidate {
	
 public static void checkValidate(UserRegistration userRegistration,List<String> error) {

	if(userRegistration.getUserID()==0) {
		error.add("Please enter the user ID");
	}
	if(userRegistration.getUserName().isEmpty()) error.add("Please enter user name");
	if(userRegistration.getUserRole().isEmpty()) error.add("Please enter user role");
	if(userRegistration.getUserEmail().isEmpty()) error.add("Please enter user email");
	if(userRegistration.getUserDOB().isEmpty()) error.add("Please enter the user Date of birth");
	if(userRegistration.getUserPhone()==0) error.add("Please user phone number");
	if(userRegistration.getUserPassword().isEmpty()) error.add("Please enter password");
	if(userRegistration.getUserRetypePassword().isEmpty()) error.add("Please retype the password");
	if(userRegistration.getUserSecurityQuestion().equals("Select question")) error.add("Please select question");
	if(userRegistration.getUserSecurityAnswer().isEmpty()) error.add("Please enter answer");
	
	if(error.isEmpty()) {
		if(!userRegistration.getUserEmail().contains("@")) error.add("Please type a valid email");
		if((userRegistration.getUserPhone()+"").length()!=10) error.add("Please enter 10 digit contact number");
		if(!userRegistration.getUserPassword().equals(userRegistration.getUserRetypePassword())) error.add("Password is not matching");
		
		
			
	}
 }	

}
