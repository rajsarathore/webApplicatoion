package com.web.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.web.model.UserRegistration;
import com.web.validation.RegistrationValidate;


public class RegistrationController extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	UserRegistration userRegistration=new UserRegistration();
	//user data from Registraion form
	List<String> errors=new ArrayList<>(); 
	userRegistration.setUserID(Long.parseLong(request.getParameter("userID").toString()));
	userRegistration.setUserName(request.getParameter("userName"));
	userRegistration.setUserRole(request.getParameter("userRole"));
	userRegistration.setUserEmail(request.getParameter("userEmail"));
	userRegistration.setUserDOB(request.getParameter("userDOB"));
	userRegistration.setUserPhone(Long.parseLong(request.getParameter("userPhone")));
	userRegistration.setUserPassword(request.getParameter("userPassword"));
	userRegistration.setUserRetypePassword(request.getParameter("userRetypePassword"));
	userRegistration.setUserSecurityQuestion(request.getParameter("userSecurityQuestion"));
	userRegistration.setUserSecurityAnswer(request.getParameter("userSecurityAnswer"));
	HttpSession httpSession=request.getSession();
	httpSession.setAttribute("errors", errors);
	
	RegistrationValidate.checkValidate(userRegistration, errors);
	if(!errors.isEmpty()) {
		
	}
	RequestDispatcher dispatcher=request.getRequestDispatcher("/common/registration.jsp");
	dispatcher.forward(request, response);
	}

}
